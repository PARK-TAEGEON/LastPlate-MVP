import re
import numpy as np
import pandas as pd
from .config import STAFF, WEATHER, MENU_RULES, feature_names, weather_feature_names

def menu_features(menu):
    # Remove origin annotations to avoid e.g. 국 in 국내산 triggering soup.
    cleaned = re.sub(r'\([^)]*(?:원산지|국내산|수입산|호주산|미국산)[^)]*\)', '', menu)
    return {name: int(bool(re.search(pattern, cleaned, flags=re.I))) for name, pattern in MENU_RULES.items()}

def build_features(d, group, weather_features=None):
    x = d[STAFF].copy()
    if group in 'BCD':
        day = pd.to_datetime(d['date']).dt.dayofweek
        for i in range(7):
            x[f'weekday_{i}'] = (day == i).astype(int)
    if group in 'CD':
        m = pd.DataFrame([menu_features(v) for v in d['menu']], index=d.index)
        x = pd.concat([x, m], axis=1)
    if group == 'D':
        selected = weather_feature_names(weather_features)
        missing = set(selected) - set(d)
        if missing:
            raise ValueError(f'Missing weather fields: {sorted(missing)}')
        for c in selected:
            x[c] = pd.to_numeric(d[c], errors='raise')
            if not np.isfinite(x[c]).all():
                raise ValueError('D requires complete weather on the same comparison rows')
    return x[feature_names(group, weather_features)].astype(float)
